import { Component } from '@angular/core';


@Component({
    selector: 'resetpass',
    templateUrl: './reset-pass.html'
})

export class RemovePassComponent {
        user:string;
    username:string;
    password:string;
    account:string;
    role:string;
    manager:string;
}
