"use strict";
var LogsTemplate = (function () {
    function LogsTemplate() {
    }
    return LogsTemplate;
}());
exports.LogsTemplate = LogsTemplate;
//# sourceMappingURL=log-entity.js.map
