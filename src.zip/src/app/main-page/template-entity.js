"use strict";
var Templates = (function () {
    function Templates() {
    }
    return Templates;
}());
exports.Templates = Templates;
//# sourceMappingURL=template-entity.js.map
