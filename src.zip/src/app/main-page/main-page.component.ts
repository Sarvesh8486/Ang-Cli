import {
    Component, ViewContainerRef, ViewChild, ElementRef, ViewEncapsulation,
    OnChanges, SimpleChanges, Input, OnInit
} from '@angular/core';
import { Templates } from './template-entity';
import { PlatformLocation } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Http, Response } from '@angular/http';
import { FileUploader, FileItem, ParsedResponseHeaders } from 'ng2-file-upload';
import { ParamsPopupComponent } from '../params-popup/params-popup.component';

@Component({
    selector: 'main-page',
    templateUrl: './main-page.html',


})
export class MainPageComponent implements OnInit {
    cloudSearch: string;
    username: string;
    password: string;
    url: string;
    selected: boolean;
    templates: Array<Templates>;
    user: string;
    scheduling: boolean;
    uploader: FileUploader;
    visible: boolean;
    selectedIndex: Number = -1;
    schedule: string = null;
    dayofexe: string;
    keys: string[];
    values: string[] = new Array();
    showPopup: Boolean = false;
    @ViewChild('timeofexe2') timeofexe2: ElementRef;
    @ViewChild('timeofexe1') timeofexe1: ElementRef;
    @ViewChild('timeofexe') timeofexe: ElementRef;
    @ViewChild('dateofexe2') dateofexe2: ElementRef;
    @ViewChild('dateofexe1') dateofexe1: ElementRef;

    onClickChange() {
        if (this.password === undefined || this.password.length <= 0) {
            alert('Enter Password of Instance');
            return;
        }
        if (this.username === undefined || this.username.length <= 0) {
            alert('Enter username of Instance');
            return;
        }
        if (this.url === undefined || this.url.length <= 0) {
            alert('Enter url of Instance');
            return;
        }
        if (this.selectedIndex === -1) {
            alert('Select One Interface');
            return;
        }
        if (this.schedule === null) {
            alert('Select Scheduling');
            return;
        }

        if (this.schedule === 'yes') {
            alert('Select Scheduling Data');
        }
        if (this.schedule === 'yes1') {
            if (this.dayofexe == null) {
                alert('Enter day of scheduling');
                return;
            } else if (this.timeofexe.nativeElement.value == null) {
                alert('Enter time of scheduling');
                return;
            } else {
                this.schedule = '1 ' + this.dayofexe + ' ' + this.timeofexe.nativeElement.value;
            }
        } else if (this.schedule === 'yes2') {
            if (this.dateofexe1.nativeElement.value == null) {
                alert('Enter day of scheduling');
                return;
            } else if (this.timeofexe1.nativeElement.value == null) {
                alert('Enter time of scheduling');
                return;
            } else {
                this.schedule = '2 ' + this.dateofexe1.nativeElement.value + ' ' + this.timeofexe1.nativeElement.value;
            }
        } else if (this.schedule === 'yes3') {
            if (this.dateofexe2.nativeElement.value == null) {
                alert('Enter day of scheduling');
                return;
            } else if (this.timeofexe2.nativeElement.value == null) {
                alert('Enter time of scheduling');
                return;
            } else {
                this.schedule = '3 ' + this.dateofexe2.nativeElement.value + ' ' + this.timeofexe2.nativeElement.value;
            }
        } else if (this.schedule !== 'yes3' && this.schedule !== 'yes1' && this.schedule !== 'yes2' && this.schedule !== 'no') {
            alert('Enter scheduling data');
            return;
        }
        const template = this.templates[this.selectedIndex.valueOf()];
        if (template.excel === null || template.excel.length === 0) {
            alert('Select file for selected template');
            return;
        } else if (template.ucm === null || template.ucm.length === 0) {
            alert('Select ucm for selected template');
            return;
        }
    }


    onChangeDay(event) {
        this.dayofexe = event;
    }

    trackByIndex(index: number, obj: any): any {
        return index;
    }

    ngOnInit() {
        this.user = sessionStorage.getItem('currentUser');
        this.location.onPopState(() => {
            sessionStorage.removeItem('currentUser');
        });
        this.uploader = new FileUploader({ url: 'http://localhost:3001/upload', autoUpload: true, });
        this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
        this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
    }

    setradio(state: string) {
        if (state !== 'yes') {
            this.schedule = state;
        }
    }

    done() {
        console.log(this.values);
    }

    constructor(private location: PlatformLocation, private http: Http) {
        this.http.get('/assets/templates.json')
            .subscribe((success) => {
                this.templates = success.json();
            });
    }

    actionClick(index: number) {
        const element: HTMLElement = document.getElementById('myFileInput' + index);
        console.log(element.id);
        console.log(element.getAttribute('value'));
        element.click();
        console.log(element.getAttribute('value'));
    }

    selectItem(index: number) {
        if (this.selectedIndex !== -1 && this.templates[index].select) {
            alert('You have already selected one interface, please unselect it first');
            setTimeout(() => {
                this.templates[index].select = false;
            });
        } else if (!this.templates[index].select) {
            this.selectedIndex = -1;
        } else {
            this.selectedIndex = index;
        }
    }

    logout() {
        sessionStorage.removeItem('currentUser');
    }

    onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
        const data = JSON.parse(response); // success server response
        console.log(data.path);
    }

    onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
        const error = JSON.parse(response); // error server response
        console.log(error);
    }

    onParamClick(template: Templates) {
        console.log(template.paramkey);
        this.showPopup = !this.showPopup;
        this.keys = template.paramkey;
        this.values = new Array();
    }




}
